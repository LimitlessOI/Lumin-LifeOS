# Founder Packet

## Mission
Build the minimal Factory v1 execution slice inside the current repo without changing existing product behavior.

## Objective
Prove one end-to-end governed execution path:

Founder Packet
-> BPB handoff pack
-> Builder executes one frozen step
-> SENTRY verifies result
-> Historian records outcome
-> TSOS records metrics

## Required outcome
Create an isolated implementation under `factory-v1/` that exposes one route:

- `POST /api/v1/factory/execute-step`

This route must:
- accept exactly one frozen step object plus matching acceptance tests
- execute only the allowed action in that step
- verify the result
- record Historian receipt
- record TSOS receipt
- return only `DONE`, `BLOCKED_RETURN_TO_BPB`, or `FAILED_VERIFICATION`

## Hard non-goals
- no autonomous work selection
- no support-task generation
- no fallback generation
- no patch-plan generation
- no self-improvement loop
- no product feature work
- no edits to existing BuilderOS planning logic in this mission

## Constraints
- use ESM
- use ASCII only
- keep new implementation isolated under `factory-v1/`
- Builder must have zero task discretion
- if spec is insufficient, Builder must return `BLOCKED_RETURN_TO_BPB`

## Definition of done
Mission is done only when a sample frozen step can pass through the full route and produce:
- Builder result
- SENTRY verification result
- Historian receipt
- TSOS receipt
