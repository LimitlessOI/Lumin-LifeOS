# FACTORY-0001-v1

This directory is the exact BPB handoff pack for the first Factory v1 proof mission.

Purpose:
- provide one machine-first blueprint pack that a low-discretion Builder can execute
- provide one pack that GPT and Claude can audit in the SENTRY role
- provide one pack that can be compared against the current BPB output

Execution order:
1. `FOUNDER_PACKET.md`
2. `AUTHORITY_CHECK.json`
3. `SALVAGE_MAP.json`
4. `BLOCKED_RETURN_SCHEMA.json`
5. `ACCEPTANCE_TESTS.json`
6. `BLUEPRINT.json`

Builder should consume:
- `BLUEPRINT.json`
- `ACCEPTANCE_TESTS.json`
- `BLOCKED_RETURN_SCHEMA.json`

This pack is not a philosophy document. It is a constrained execution packet for the first proof mission only.

Freeze blockers already addressed in this version:
- Builder writes must remain inside `factory-v1/`
- proof execution acceptance tests come from a blueprint-owned registry, not request body
- SENTRY verifies exact file content where blueprint requires exact output

Honest proof-slice naming in this mission:
- Historian is only a receipt recorder
- TSOS is only a metrics recorder
