# Manifest

This export is the external review packet for `FACTORY-0001-v1`.

Use these files:

1. `GPT_REVIEW_PROMPT.md`
2. `FOUNDER_PACKET.md`
3. `BLUEPRINT.json`
4. `ACCEPTANCE_TESTS.json`
5. `AUTHORITY_CHECK.json`
6. `SALVAGE_MAP.json`
7. `BLOCKED_RETURN_SCHEMA.json`
8. `../SALVAGE_CANDIDATES.json`

Purpose:
- send to GPT or another external model with no repo access
- have it act as `SENTRY`
- audit the machine-first blueprint pack
